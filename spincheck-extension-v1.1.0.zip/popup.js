const $ = (id) => document.getElementById(id);

// Phases shown in the popup timeline. `finding_sources` is intentionally
// excluded — the extension sends skipReading=true to /api/analyze, so that
// phase never fires (reading is fetched on-demand via the button instead).
const POPUP_PHASES = [
  { id: 'reading',            label: 'Reading the article',          seconds: 3  },
  { id: 'assessing',          label: 'Assessing political bias',     seconds: 4  },
  { id: 'writing_analysis',   label: 'Writing detailed analysis',    seconds: 12 },
  { id: 'gathering_evidence', label: 'Gathering evidence',           seconds: 6  },
  { id: 'finding_omissions',  label: "Looking for what's missing",   seconds: 4  },
  { id: 'perspectives',       label: 'Steel-manning both sides',     seconds: 7  },
  { id: 'common_ground',      label: 'Looking for common ground',    seconds: 3  },
];

const CHECK_SVG = '<svg viewBox="0 0 20 20" width="9" height="9" fill="currentColor" aria-hidden="true"><path d="M16.7 5.3a1 1 0 0 1 0 1.4l-8 8a1 1 0 0 1-1.4 0l-4-4a1 1 0 0 1 1.4-1.4L8 12.6l7.3-7.3a1 1 0 0 1 1.4 0z"/></svg>';

function updatePhase(phase) {
  const currentIdx = Math.max(0, POPUP_PHASES.findIndex((p) => p.id === phase));
  const remaining = POPUP_PHASES.slice(currentIdx).reduce((s, p) => s + p.seconds, 0);
  $('loading-remaining').textContent = `~${remaining}s remaining`;

  $('timeline').innerHTML = POPUP_PHASES.map((p, i) => {
    const state = i < currentIdx ? 'done' : i === currentIdx ? 'current' : 'pending';
    const showConnector = i < POPUP_PHASES.length - 1;
    return `
      <li class="tl-item tl-${state}">
        ${showConnector ? '<span class="tl-connector"></span>' : ''}
        <span class="tl-marker">${state === 'done' ? CHECK_SVG : ''}</span>
        <span class="tl-label">${escHtml(p.label)}</span>
        <span class="tl-time">~${p.seconds}s</span>
      </li>`;
  }).join('');
}

const states = {
  idle: $('idle-state'),
  loading: $('loading-state'),
  result: $('result-state'),
  error: $('error-state'),
};

function showState(name) {
  Object.entries(states).forEach(([k, el]) => el.classList.toggle('hidden', k !== name));
}

function switchTab(section) {
  document.querySelectorAll('.tab').forEach((t) =>
    t.classList.toggle('active', t.dataset.section === section)
  );
  document.querySelectorAll('.section').forEach((s) => {
    s.classList.toggle('hidden', !s.id.endsWith(section));
    s.classList.toggle('active', s.id.endsWith(section));
  });
}

document.querySelectorAll('.tab').forEach((t) =>
  t.addEventListener('click', () => switchTab(t.dataset.section))
);

let currentUrl = '';
let currentTabId = null;

document.addEventListener('DOMContentLoaded', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab) {
    currentUrl = tab.url || '';
    currentTabId = tab.id;
    const displayUrl = currentUrl.replace(/^https?:\/\/(www\.)?/, '').substring(0, 55);
    $('page-url').textContent = displayUrl || 'Unknown page';
  }

  // Check storage to resume any in-flight or completed analysis
  const key = `sc_${currentUrl}`;
  const stored = (await chrome.storage.local.get(key))[key];
  const age = stored ? Date.now() - stored.ts : Infinity;
  const FIVE_MIN = 5 * 60 * 1000;
  const ONE_DAY = 24 * 60 * 60 * 1000;

  if (stored?.status === 'complete' && age < ONE_DAY) {
    renderResult(stored.data);
  } else if (stored?.status === 'analyzing' && age < FIVE_MIN) {
    // Background is still working — show loading with last known phase
    showState('loading');
    if (stored.phase) updatePhase(stored.phase);
    listenForCompletion();
  } else if (stored?.status === 'error' && age < FIVE_MIN) {
    $('error-msg').textContent = stored.error;
    showState('error');
  } else {
    showState('idle');
  }
});

function listenForCompletion() {
  function handler(message) {
    if (message.url !== currentUrl) return;
    if (message.action === 'analysisPhase') {
      updatePhase(message.phase);
      return; // don't remove listener — more events coming
    }
    chrome.runtime.onMessage.removeListener(handler);
    if (message.action === 'analysisComplete') {
      renderResult(message.data);
    } else if (message.action === 'analysisError') {
      $('error-msg').textContent = message.error;
      showState('error');
    }
  }
  chrome.runtime.onMessage.addListener(handler);
}

$('analyze-btn').addEventListener('click', async () => {
  if (!currentTabId || !currentUrl) return;
  showState('loading');
  updatePhase('reading');
  listenForCompletion();
  chrome.runtime.sendMessage({ action: 'startAnalysis', tabId: currentTabId, url: currentUrl });
});

$('re-analyze-btn').addEventListener('click', async () => {
  await chrome.storage.local.remove(`sc_${currentUrl}`);
  showState('idle');
});

$('retry-btn').addEventListener('click', async () => {
  await chrome.storage.local.remove(`sc_${currentUrl}`);
  showState('idle');
});

function getScoreLabel(score) {
  if (score <= 0) return 'No Bias';
  if (score <= 2) return 'Slight Bias';
  if (score <= 4) return 'Mild Bias';
  if (score <= 6) return 'Moderate Bias';
  if (score <= 8) return 'Strong Bias';
  return 'Extreme Bias';
}

function renderResult(a) {
  const dir = a.direction;
  const score = a.score;
  const scoreStr = dir === 'left' ? `${score}L` : dir === 'right' ? `${score}R` : `${score}`;
  const dirLabel = dir === 'none' ? '' : dir === 'left' ? ' — Leans Left' : ' — Leans Right';

  const scoreText = getScoreLabel(score);
  $('score-value').textContent = scoreStr;
  $('score-value').className = `score-value ${dir}`;
  $('score-label').textContent = scoreText + dirLabel;

  const clamped = Math.max(0, Math.min(10, score));
  const val = dir === 'none' ? 0 : dir === 'left' ? -clamped : clamped;
  const pct = ((val + 10) / 20) * 100;
  const dot = $('gauge-dot');
  dot.style.left = `${pct}%`;
  dot.style.backgroundColor = dir === 'left' ? '#3b82f6' : dir === 'right' ? '#ef4444' : '#6b7280';

  $('summary').textContent = a.summary;

  $('badges').innerHTML = [
    badge(a.isEditorial, '📝 Editorial', '📰 Factual', true),
    badge(!a.presentsBothSides, '✗ One-Sided', '✓ Balanced', true),
    badge(a.usesEmotionalLanguage, '⚠ Emotional Language', '✓ Neutral Tone', true),
    badge(a.hasSelectiveSourcing, '⚠ Selective Sourcing', '✓ Diverse Sources', true),
    badge(a.hasMisleadingHeadline, '⚠ Misleading Headline', '✓ Accurate Headline', true),
  ].join('');

  // Append confidence pill to score label
  if (a.confidence) {
    $('score-label').innerHTML = `${escHtml(scoreText + dirLabel)} <span class="conf-pill conf-${a.confidence}">${a.confidence}</span>`;
  }

  const framingHtml = a.framingEvidence?.length
    ? `<div style="margin-top:12px;padding-top:10px;border-top:1px solid #1e2533">
        <div style="font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">How the article frames things</div>
        ${a.framingEvidence.map((e) => `<div class="ev-item">"${escHtml(e)}"</div>`).join('')}
       </div>`
    : '';

  const omissionHtml = a.omissionEvidence?.length
    ? `<div style="margin-top:12px;padding-top:10px;border-top:1px solid #1e2533">
        <div style="font-size:10px;font-weight:600;color:#f59e0b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px">What's missing or downplayed</div>
        ${a.omissionEvidence.map((e) => `<div class="ev-item" style="font-style:normal;border-left-color:rgba(245,158,11,0.4)">${escHtml(e)}</div>`).join('')}
       </div>`
    : '';

  $('section-analysis').innerHTML = `<p>${escHtml(a.analysis).replace(/\n/g, '<br>')}</p>${framingHtml}${omissionHtml}`;

  const p = a.perspectives;
  const articleLabel = a.direction === 'left' ? 'Progressive Perspective'
    : a.direction === 'right' ? 'Conservative Perspective' : "Article's View";
  const opposingLabel = a.direction === 'left' ? 'Conservative Counter-Argument'
    : a.direction === 'right' ? 'Progressive Counter-Argument' : 'Opposing View';

  const hasPerspectiveContent = !!p.opposingView || !!p.commonGround;

  if (!hasPerspectiveContent && a.direction === 'none') {
    $('section-steelman').innerHTML = `
      <div style="text-align:center;padding:16px 0">
        <div style="font-size:24px;margin-bottom:8px">⚖️</div>
        <p style="color:#cbd5e1;font-size:12px;font-weight:600">This topic isn't politically contested.</p>
        <p style="color:#64748b;font-size:11px;margin-top:4px">No meaningful left/right debate applies.</p>
      </div>`;
  } else {
    const commonHtml = p.commonGround
      ? `<div style="margin-bottom:10px">
          <div class="sm-head" style="margin-bottom:5px;color:#c084fc">🤝 Common Ground</div>
          <div style="background:rgba(168,85,247,0.1);border:1px solid rgba(168,85,247,0.3);border-radius:6px;padding:8px"><p>${escHtml(p.commonGround)}</p></div>
        </div>`
      : '';

    const articleHtml = `
      <div style="margin-bottom:10px">
        <div class="sm-head ${a.direction === 'left' ? 'left' : a.direction === 'right' ? 'right' : ''}" style="margin-bottom:5px">1 · ${escHtml(articleLabel)}</div>
        <div class="${a.direction === 'left' ? 'sm-left' : a.direction === 'right' ? 'sm-right' : 'sm-left'}"><p>${escHtml(p.articleView)}</p></div>
      </div>`;

    const opposingHtml = p.opposingView
      ? `<div>
          <div class="sm-head ${a.direction === 'left' ? 'right' : a.direction === 'right' ? 'left' : ''}" style="margin-bottom:5px">2 · ${escHtml(opposingLabel)}</div>
          <div class="${a.direction === 'left' ? 'sm-right' : a.direction === 'right' ? 'sm-left' : 'sm-right'}"><p>${escHtml(p.opposingView)}</p></div>
        </div>`
      : '';

    $('section-steelman').innerHTML = `
      <p style="font-size:10px;color:#475569;margin-bottom:10px">Topic: ${escHtml(p.topic)}</p>
      ${commonHtml}
      ${articleHtml}
      ${opposingHtml}`;
  }

  // Reading is now fetched on-demand. Show a button until the user requests it.
  renderReadingSection(a);

  // Reset feedback UI state for this result
  resetFeedbackUi(a);

  switchTab('analysis');
  showState('result');
}

// ─────────── Feedback ───────────

let feedbackVote = null;
let feedbackAnalysis = null;

function resetFeedbackUi(analysis) {
  feedbackVote = null;
  feedbackAnalysis = analysis;
  $('feedback-prompt').classList.remove('hidden');
  $('feedback-comment').classList.add('hidden');
  $('feedback-done').classList.add('hidden');
  $('fb-comment-text').value = '';
}

function handleFeedbackVote(vote) {
  feedbackVote = vote;
  $('feedback-prompt').classList.add('hidden');
  $('feedback-comment').classList.remove('hidden');
  $('fb-comment-prompt').textContent =
    vote === 'up'
      ? 'Glad it was helpful! What worked? (optional)'
      : 'Sorry the analysis missed the mark. What was off? (optional)';
  $('fb-comment-text').placeholder =
    vote === 'up' ? 'What was useful?' : 'What was wrong or missing?';
  $('fb-comment-text').focus();
}

async function submitFeedback() {
  if (!feedbackVote || !feedbackAnalysis) return;

  const btn = $('fb-submit');
  btn.disabled = true;
  btn.textContent = 'Sending…';

  // Derive feedback URL from the analyze URL by swapping the path
  const feedbackUrl = SPINCHECK_CONFIG.API_URL.replace(/\/api\/[^/?#]+/, '/api/feedback');

  try {
    await fetch(feedbackUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        vote: feedbackVote,
        comment: $('fb-comment-text').value.trim() || undefined,
        url: currentUrl,
        analysis: feedbackAnalysis,
        source: 'extension',
      }),
    });
  } catch {
    // Fire-and-forget — proceed to thanks even on failure
  } finally {
    $('feedback-comment').classList.add('hidden');
    $('feedback-done').classList.remove('hidden');
    btn.disabled = false;
    btn.textContent = 'Submit';
  }
}

function cancelFeedback() {
  feedbackVote = null;
  $('fb-comment-text').value = '';
  $('feedback-comment').classList.add('hidden');
  $('feedback-prompt').classList.remove('hidden');
}

// Bind once at startup
$('fb-up').addEventListener('click', () => handleFeedbackVote('up'));
$('fb-down').addEventListener('click', () => handleFeedbackVote('down'));
$('fb-submit').addEventListener('click', submitFeedback);
$('fb-cancel').addEventListener('click', cancelFeedback);

function renderReadingSection(a) {
  if (a.furtherReading && a.furtherReading.length) {
    // Already loaded — render directly
    $('section-reading').innerHTML = a.furtherReading.map((r) => `
        <div class="read-item">
          <div class="read-desc">${escHtml(r.description)}</div>
          <a class="read-link" href="https://www.google.com/search?q=${encodeURIComponent(r.searchQuery)}" target="_blank">
            🔍 "${escHtml(r.searchQuery)}"
          </a>
        </div>`).join('');
    return;
  }

  // Show the load button
  $('section-reading').innerHTML = `
    <div style="text-align:center;padding:12px 0">
      <p style="color:#94a3b8;font-size:12px;margin-bottom:10px">
        Find sources from across the political spectrum to round out your perspective on this topic.
      </p>
      <button id="load-reading-btn" class="btn-primary" style="font-size:12px;padding:8px 14px">
        🔍 Find balanced sources
      </button>
      <p id="reading-error" style="color:#f87171;font-size:11px;margin-top:8px;display:none"></p>
    </div>`;

  $('load-reading-btn').addEventListener('click', () => loadReading(a));
}

async function loadReading(a) {
  const btn = $('load-reading-btn');
  const errEl = $('reading-error');
  btn.disabled = true;
  btn.textContent = 'Finding sources…';
  errEl.style.display = 'none';

  try {
    const apiBase = SPINCHECK_CONFIG.API_URL.replace(/\/api\/.*$/, '');
    const res = await fetch(`${apiBase}/api/reading`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        topic: a.perspectives?.topic || '',
        direction: a.direction,
        summary: a.summary,
      }),
    });

    const data = await res.json();
    if (!data.success) throw new Error(data.error || 'Failed to load reading');

    // Cache on the analysis object and re-render
    a.furtherReading = data.data || [];

    // Update cached storage so re-opening the popup has it
    if (currentUrl) {
      chrome.storage.local.get(`sc_${currentUrl}`).then((stored) => {
        const entry = stored[`sc_${currentUrl}`];
        if (entry?.status === 'complete') {
          entry.data.furtherReading = a.furtherReading;
          chrome.storage.local.set({ [`sc_${currentUrl}`]: entry });
        }
      });
    }

    renderReadingSection(a);
  } catch (err) {
    btn.disabled = false;
    btn.textContent = '🔍 Find balanced sources';
    errEl.textContent = err.message || 'Could not load sources. Try again.';
    errEl.style.display = 'block';
  }
}

function badge(isActive, trueLabel, falseLabel, warnOnTrue) {
  const warn = warnOnTrue ? isActive : !isActive;
  const cls = warn ? 'b-warn' : 'b-good';
  return `<span class="badge ${cls}">${escHtml(isActive ? trueLabel : falseLabel)}</span>`;
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
